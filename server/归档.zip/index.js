const keys = require('./keys');

const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(bodyParser());

//Postgres
const { Pool } = require('pg'); //新建pool
const pgClient = new Pool({
    user: keys.pgUser,
    host: keys.pgHost,
    database: keys.pgDatabase,
    password: keys.pgPassword,
    port: keys.pgPort,
});

pgClient.on('connect', () => {
    pgClient
        .query('CREATE TABLE IF NOT EXISTS values (number INT)')
        .catch((err) => console.log(err));
});

//redis
const redis = require('redis');
const redisClient = redis.createClient({
    //新建redis客户端
    host: keys.redisClient,
    port: keys.redisPort,
    retry_strategy: () => 1000,
});

const redisPublisher = redisClient.duplicate();

//Express router handlers
app.get('/', (req, res) => {
    res.send('Hi');
});

app.post('/values', async (req, res) => {
    //将用户填写的数字发送到Worker
    const index = req.body.index;
    if (parseInt(index) > 100) {
        return res.status(422).send('Index too high.');
    }

    redisClient.hset('values', index, 'Nothing yet.'); //将数字push到redis存储,Nothing yet是将要被values替换的初始值
    redisPublisher.publish('insert', index); //触发insert事件,让worker准备去计算.
    pgClient.query('INSERT INTO values(number) VALUES($1)', [index]);
    res.send({ working: true });
});

app.get('/values/all', async (req, res) => {
    //获取PG数据库里所有已存储的数字
    const values = await pgClient.query('SELECT * from values');
    res.send(values.rows);
});

app.get('/values/current', async (req, res) => {
    //获取Redis所有worker计算过的数字和index
    redisClient.hgetall('values', (err, values) => {
        res.send(values);
    });
});

app.listen(5000, (err) => {
    console.log('Listening ...');
});
